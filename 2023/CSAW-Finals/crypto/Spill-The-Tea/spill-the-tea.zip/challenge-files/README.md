# Spill the Tea

> Oh no! I dropped my flag and spilled my tea while updating [ctf.csaw.io](https://ctf.csaw.io)! Can you help a poor girl get her flag back?

-- Maya

## Running
Run `yarn install` (or your choice of package manager) and then `yarn dev`. Should work on any version of nodejs compatible with Vite 4.
