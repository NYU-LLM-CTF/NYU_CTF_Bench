ACME Co's update server has been stolen and posted on 
the internet.  It seems like a bunch of janky python 
code.  See if you can perform some ownage. 

ec2-54-226-104-14.compute-1.amazonaws.com

Note:
Your instance is specific to your team.  Unless you want 
other teams messing with your instance and potentially
denial-of-servicing you, keep your instance location a
team secret.