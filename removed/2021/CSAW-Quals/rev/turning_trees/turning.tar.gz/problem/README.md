
# Tur(n)ing Trees

TODO:
- cleanup code
- _microservices_
- thank Draknek for [A Monster's Expedition](https://www.monsterexpedition.com/)
- invest in crypto
- something, something, _big data_
- beat level 2...

# Run:
```
python3 -m turning.main
```

you need `pygame` and `numpy`
```
python3 -m pip install pygame numpy
```

# Controls

```
Move: WASD/arrows
Zoom in: E
Zoom out: Q
Undo: Z
Reset: R
Move fast: hold SHIFT
```
