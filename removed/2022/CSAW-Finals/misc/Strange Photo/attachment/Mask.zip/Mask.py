import torch.nn as nn
import torch.nn.functional as func

class Mask(nn.Module):

    def __init__(self):
        super(Mask, self).__init__()
        self.conv1 = nn.Conv2d(1, 6, 5)
        self.conv2 = nn.Conv2d(6, 16, 5)
        self.linear1 = nn.Linear(256, 784)

    def forward(self, x):
        x = func.relu(self.conv1(x))
        x = func.max_pool2d(x, 2)
        x = func.relu(self.conv2(x))
        x = func.max_pool2d(x, 2)
        x = x.view(x.size(0), -1)
        x = func.relu(self.linear1(x)).reshape((28,28)).tolist()
        for i in range(28):
            for j in range(28):
                x[i][j] = int(x[i][j] * 255)
                if (x[i][j] > 255):
                    x[i][j] = 255
        return x