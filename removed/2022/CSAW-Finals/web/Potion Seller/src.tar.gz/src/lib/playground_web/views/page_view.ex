defmodule PlaygroundWeb.PageView do
  use PlaygroundWeb, :view
end
