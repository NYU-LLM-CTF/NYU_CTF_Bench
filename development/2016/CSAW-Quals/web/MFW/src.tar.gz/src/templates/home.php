<h1 style="text-align: center">Welcome to my website!<br>I wrote it myself from scratch!</h1>
<br/>
<p>You can use the links above to navigate through the pages!</p>