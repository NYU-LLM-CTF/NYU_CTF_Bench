<h1>About</h1>
<p>I wrote this website all by myself in under a week!</p>
<p>I used:</p>
<ul>
	<li>Git</li>
	<li>PHP</li>
	<li>Bootstrap</li>
</ul>