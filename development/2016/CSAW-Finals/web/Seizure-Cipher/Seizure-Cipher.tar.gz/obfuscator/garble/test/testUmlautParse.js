var specialCharTestü = function() {
    console.log( "testUmlautParse pass" );
};

specialCharTestü();