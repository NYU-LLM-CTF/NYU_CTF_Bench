var specialCharTest = function() {
    var test = "—something";
    console.log( "testLongHyphenParse pass" );
};

specialCharTest();