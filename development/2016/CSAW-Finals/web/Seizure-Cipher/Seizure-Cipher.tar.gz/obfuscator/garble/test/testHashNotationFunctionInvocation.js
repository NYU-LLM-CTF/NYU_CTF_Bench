this.case1 = function() {
    console.log( "testHashNotationFunctionInvocation pass" );
};

this[ "case1" ]();