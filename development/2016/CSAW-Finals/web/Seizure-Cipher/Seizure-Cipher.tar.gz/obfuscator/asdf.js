asdf = [
	new Point(27,72),
	new Point(43,69),
	new Point(27,39),
	new Point(53,55),
	new Point(64,56),
	new Point(70,69),
	new Point(53,70),
	new Point(53,39),
	new Point(68,40),
	new Point(70,48),
	new Point(61,36),
	new Point(52,47),
	new Point(53,62),
	new Point(68,62),
	new Point(34,72),
	new Point(28,62),
	new Point(27,51),
	new Point(95,55),
	new Point(99,55),
	new Point(100,64),
	new Point(95,72),
	new Point(86,66),
	new Point(80,57),
	new Point(82,48),
	new Point(86,39),
	new Point(97,38),
	new Point(100,39),
	new Point(110,69),
	new Point(110,60),
	new Point(110,51),
	new Point(110,38),
	new Point(116,43),
	new Point(120,53),
	new Point(127,45),
	new Point(132,38),
	new Point(132,47),
	new Point(132,57),
	new Point(132,64),
	new Point(135,69),
	new Point(157,78),
	new Point(152,76),
	new Point(150,65),
	new Point(150,56),
	new Point(139,51),
	new Point(152,44),
	new Point(152,34),
	new Point(161,30),
	new Point(170,66),
	new Point(175,70),
	new Point(182,64),
	new Point(186,53),
	new Point(186,40),
	new Point(178,39),
	new Point(169,39),
	new Point(201,70),
	new Point(200,61),
	new Point(200,51),
	new Point(200,40),
	new Point(207,51),
	new Point(215,44),
	new Point(219,40),
	new Point(211,56),
	new Point(215,62),
	new Point(219,70),
	new Point(238,70),
	new Point(238,60),
	new Point(238,47),
	new Point(238,36),
	new Point(246,39),
	new Point(228,39),
	new Point(259,39),
	new Point(267,39),
	new Point(276,39),
	new Point(266,45),
	new Point(266,52),
	new Point(267,61),
	new Point(267,69),
	new Point(287,38),
	new Point(287,48),
	new Point(287,57),
	new Point(289,66),
	new Point(296,72),
	new Point(304,68),
	new Point(306,57),
	new Point(308,47),
	new Point(306,34),
	new Point(313,81),
	new Point(323,81),
	new Point(331,81),
	new Point(340,81),
	new Point(343,39),
	new Point(348,47),
	new Point(351,55),
	new Point(358,52),
	new Point(364,45),
	new Point(368,35),
	new Point(356,61),
	new Point(356,70),
	new Point(376,40),
	new Point(375,47),
	new Point(376,55),
	new Point(376,61),
	new Point(376,69),
	new Point(385,49),
	new Point(389,43),
	new Point(394,36),
	new Point(385,60),
	new Point(392,65),
	new Point(398,72),
	new Point(415,68),
	new Point(414,59),
	new Point(414,48),
	new Point(415,36),
	new Point(423,36),
	new Point(406,38),
	new Point(431,40),
	new Point(435,47),
	new Point(441,56),
	new Point(448,51),
	new Point(453,40),
	new Point(444,65),
	new Point(444,70),
	new Point(461,70),
	new Point(461,62),
	new Point(462,55),
	new Point(462,44),
	new Point(462,38),
	new Point(470,45),
	new Point(473,53),
	new Point(479,64),
	new Point(482,70),
	new Point(482,57),
	new Point(483,49),
	new Point(483,39),
	new Point(503,72),
	new Point(512,66),
	new Point(515,56),
	new Point(514,47),
	new Point(508,39),
	new Point(502,38),
	new Point(494,41),
	new Point(490,52),
	new Point(493,62),
	new Point(497,70),
	new Point(516,81),
	new Point(521,81),
	new Point(529,81),
	new Point(539,81),
	new Point(549,41),
	new Point(553,51),
	new Point(553,55),
	new Point(556,66),
	new Point(563,68),
	new Point(567,57),
	new Point(570,44),
	new Point(569,48),
	new Point(583,40),
	new Point(583,48),
	new Point(582,53),
	new Point(579,62),
	new Point(584,68),
	new Point(594,68),
	new Point(601,62),
	new Point(601,55),
	new Point(601,48),
	new Point(601,38),
	new Point(611,39),
	new Point(615,45),
	new Point(619,55),
	new Point(624,61),
	new Point(629,68),
	new Point(629,38),
	new Point(624,44),
	new Point(616,61),
	new Point(611,68),
	new Point(609,68),
	new Point(654,39),
	new Point(647,39),
	new Point(641,39),
	new Point(641,44),
	new Point(641,52),
	new Point(641,57),
	new Point(641,66),
	new Point(649,69),
	new Point(655,68),
	new Point(647,51),
	new Point(654,52),
	new Point(667,41),
	new Point(668,49),
	new Point(668,59),
	new Point(668,65),
	new Point(672,41),
	new Point(672,48),
	new Point(678,53),
	new Point(683,45),
	new Point(688,38),
	new Point(689,47),
	new Point(689,53),
	new Point(689,66),
	new Point(700,40),
	new Point(700,49),
	new Point(700,57),
	new Point(700,64),
	new Point(705,72),
	new Point(713,69),
	new Point(718,56),
	new Point(718,49),
	new Point(718,36),
	new Point(718,62),
	new Point(727,39),
	new Point(735,40),
	new Point(746,40),
	new Point(737,47),
	new Point(737,57),
	new Point(738,65),
	new Point(738,73),
	new Point(759,32),
	new Point(764,34),
	new Point(768,39),
	new Point(768,45),
	new Point(768,52),
	new Point(775,55),
	new Point(768,57),
	new Point(767,69),
	new Point(764,76),
	new Point(758,78)
];

var points = 25;
var point_counter = 1;

var length = 35;

var path1 = new Path({
	strokeColor: '#E4141B',
	strokeWidth: 20,
	strokeCap: 'round'
});

var text = new PointText({
	point: new Point(150, 100),
	justification: 'center',
	fontSize: 100,
	fillColor: 'white'
});
text.content = "the";
var text = new PointText({
	point: new Point(150, 200),
	justification: 'center',
	fontSize: 100,
	fillColor: 'white'
});
text.content = "secrets";
var text = new PointText({
	point: new Point(150, 300),
	justification: 'center',
	fontSize: 100,
	fillColor: 'white'
});
text.content = "are";
var text = new PointText({
	point: new Point(150, 400),
	justification: 'center',
	fontSize: 100,
	fillColor: 'white'
});
text.content = "on";
var text = new PointText({
	point: new Point(150, 500),
	justification: 'center',
	fontSize: 100,
	fillColor: 'white'
});
text.content = "the";
var text = new PointText({
	point: new Point(150, 600),
	justification: 'center',
	fontSize: 100,
	fillColor: 'white'
});
text.content = "page";

var prevPoint = null,
	startTime = new Date(),
	veryStartTime = null,
	doTheFreak = false,
	showingBalls = false;

var start = view.center / [10, 1];
for (var i = 0; i < points; i++)
	path1.add(start + new Point(i * length, 0));

function onMouseMove(event) {
	if (prevPoint == null) {
		prevPoint = event.point;
	} else {
		var dist = prevPoint.getDistance(event.point);
		if (dist < 300) {
			var newTime = new Date();
			if (newTime - startTime < 100) {
				if (veryStartTime == null) {
					veryStartTime = new Date();
				} else {
					if (newTime - veryStartTime > 1500) {
						doTheFreak = true;
					} else {
						doTheFreak = false;
					};
				};
			} else {
				veryStartTime = null;
				doTheFreak = false;
			}
			startTime = newTime;
		} else {
			doTheFreak = false;
		};
	}

	path1.firstSegment.point = event.point;
	for (var i = 0; i < points - 1; i++) {
		var segment = path1.segments[i];
		var nextSegment = segment.next;
		var vector = segment.point - nextSegment.point;
		vector.length = length;
		nextSegment.point = segment.point - vector;
	}
	path1.smooth({ type: 'continuous' });
};

// The amount of circles we want to make:
var count = 300;

// Create a symbol, which we will use to place instances of later:
var path = new Path.Circle({
	center: [0, 0],
	radius: 30,
	fillColor: 'white',
	strokeColor: 'black'
});

var symbol = new Symbol(path),
	stars = [];

for (var i = 0; i < count; i++) {
	var center = Point.random() * view.size;
	var placedSymbol = symbol.place(center);
	placedSymbol.scale(i / count);
	stars.push(placedSymbol);
}

var startShow = null;

function onFrame(event) {
	if (doTheFreak) {
		if (!showingBalls) {
			showingBalls = true;
		}
		for (var i = 0; i < stars.length; i++) {
			var item = stars[i];
			
			if (Math.random() * 10 < 2) {
				var tmp = asdf[point_counter % asdf.length];
				point_counter += 1
				item.position.x = tmp.x;
				item.position.y = tmp.y;
				item.radius = 100;
			} else {
				item.position.x += item.bounds.width * 5;
				if (item.bounds.left > view.size.width) {
					item.position.x = -item.bounds.width;
				}
				item.position.y = (Point.random() * view.size).y;
				path.fillColor = "#"+((1<<24)*Math.random()|0).toString(16);
				path.strokeColor = "#"+((1<<24)*Math.random()|0).toString(16);
			}
		}
	} else {
		showingBalls = false;
	}
}
