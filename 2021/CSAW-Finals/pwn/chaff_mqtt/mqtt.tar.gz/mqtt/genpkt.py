#!/usr/bin/env python3

import struct

def gensize(size):
    res = b''
    while size > 0:
        b = size&0x7f
        if size > 127:
            b |= 0x80
        res += struct.pack('>B', b)
        size >>= 7
    return res

ctl_flag = [2, 3, 4, 5, 6, 7, 9, 11]

def gen_publish_body(topic, msg):
    sz = 2 + len(topic) + 2 + len(msg)
    pid = 0xd34d
    body = b''
    body += struct.pack(">H", len(topic))
    body += topic
    body += struct.pack(">H", pid)
    body += msg
    return body

print(gen_publish_body(b"a"*258, b"a"))

# (Ctl, Flag, Body)
conf_combo = [
        [2, 0, b'\x01\x01'],
        [3, 3, gen_publish_body(b"X"*0x100, b"Y"*0x100)],   # QoS 2
        [5, 0, b'\xd3\x4d'],
        [4, 0, b'\xd3\x4d'],
        #[6, 0, b'\xd3\x4d'],   # rule violation
        [7, 0, b'\xd3\x4d'],
        [9, 0, b'\xd3\x4d'+b'x'*0x10],
        [11, 0, b'\xd3\x4d'],
        ]

output = b''
for ctl, flag, body in conf_combo:
    pkt = struct.pack('>B', (ctl << 4)|flag)
    pkt += gensize(len(body))
    pkt += body
    output += pkt

with open('pkts', 'wb') as fd:
    fd.write(output)
